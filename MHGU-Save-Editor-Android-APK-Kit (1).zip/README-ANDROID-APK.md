# MHGU Save Editor — Android APK Recompile Kit
Ported from `https://github.com/Scrimas/MHGU-Save-editor`

This bundle includes two complete ways to package and run **MHGU Save Editor** as a native Android `.apk` without losing any feature from the original application:

---

## Option A: 1-Click Automated APK Build via GitHub Actions (Recommended)
1. Copy `.github/workflows/android-apk.yml` into your repository.
2. Push to GitHub or trigger **Actions → Build Android APK → Run workflow**.
3. GitHub Actions automatically builds both:
   - `MHGU-Save-Editor-Mobile-WebAPK.apk` (Capacitor Android WebView APK with offline database & JKSV ZIP support)
   - `MHGU-Save-Editor-Native-Slint-arm64.apk` (Native Rust + Slint Android NDK build via `cargo-apk`)

---

## Option B: Local Capacitor Android APK Build
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npm run build
npx cap sync android
cd android && ./gradlew assembleDebug
```
Output APK: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## Option C: Native Rust + Slint (`cargo-apk`) Recompile of Scrimas/MHGU-Save-editor
The folder `rust-slint-android-patch/` contains the exact `Cargo.toml` and `android_main` entry point needed to compile `Scrimas/MHGU-Save-editor` with `slint`'s `backend-android-activity-06` backend for `aarch64-linux-android`.
