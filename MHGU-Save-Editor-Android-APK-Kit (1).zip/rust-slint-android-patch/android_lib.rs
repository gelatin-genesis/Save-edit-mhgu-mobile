// Drop into app/gui/src/android_lib.rs in Scrimas/MHGU-Save-editor
#[cfg(target_os = "android")]
#[unsafe(no_mangle)]
fn android_main(app: slint::android::AndroidApp) {
    slint::android::init(app).expect("Failed to initialize Slint Android backend");
    crate::main();
}
